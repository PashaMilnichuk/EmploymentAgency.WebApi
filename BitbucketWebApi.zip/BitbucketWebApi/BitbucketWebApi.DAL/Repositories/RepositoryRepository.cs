using BitbucketWebApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BitbucketWebApi.DAL.Repositories
{
    public interface IRepositoryRepository
    {
        Task<IEnumerable<Repository>> GetAllAsync();
        Task<Repository?> GetByIdAsync(Guid id);
        Task AddAsync(Repository repository);
        Task UpdateAsync(Repository repository);
        Task DeleteAsync(Guid id);
    }

    public class RepositoryRepository : IRepositoryRepository
    {
        private readonly BitbucketDbContext _context;

        public RepositoryRepository(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Repository>> GetAllAsync()
        {
            return await _context.Repositories
                .Include(r => r.Owner)
                .Include(r => r.Commits)
                .Include(r => r.Issues)
                .ToListAsync();
        }

        public async Task<Repository?> GetByIdAsync(Guid id)
        {
            return await _context.Repositories
                .Include(r => r.Owner)
                .Include(r => r.Commits)
                .Include(r => r.Issues)
                .FirstOrDefaultAsync(r => r.Id == id);
        }

        public async Task AddAsync(Repository repository)
        {
            await _context.Repositories.AddAsync(repository);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Repository repository)
        {
            _context.Repositories.Update(repository);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Guid id)
        {
            var repo = await _context.Repositories.FindAsync(id);
            if (repo != null)
            {
                _context.Repositories.Remove(repo);
                await _context.SaveChangesAsync();
            }
        }
    }
}
