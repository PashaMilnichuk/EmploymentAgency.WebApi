using BitbucketWebApi.DAL.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BitbucketWebApi.DAL.Repositories.Interfaces
{
    public interface IRepositoryRepository
    {
        Task<IEnumerable<Repository>> GetAllAsync();
        Task<Repository?> GetByIdAsync(Guid id);
        Task AddAsync(Repository repository);
        void Update(Repository repository);
        void Delete(Repository repository);
        Task<bool> SaveChangesAsync();
    }
}
