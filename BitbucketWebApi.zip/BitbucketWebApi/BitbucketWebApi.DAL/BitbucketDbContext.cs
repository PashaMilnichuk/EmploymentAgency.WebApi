﻿using Microsoft.EntityFrameworkCore;
using BitbucketWebApi.DAL.Entities;
using FileEntity = BitbucketWebApi.DAL.Entities.File;

namespace BitbucketWebApi.DAL
{
    public class BitbucketDbContext : DbContext
    {
        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Repository> Repositories { get; set; } = null!;
        public DbSet<RepositoriesContributor> RepositoriesContributors { get; set; } = null!;
        public DbSet<Issue> Issues { get; set; } = null!;
        public DbSet<Commit> Commits { get; set; } = null!;
        public DbSet<FileEntity> Files { get; set; } = null!;

        public BitbucketDbContext(DbContextOptions<BitbucketDbContext> options)
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasKey(u => u.Id);

            modelBuilder.Entity<Repository>()
                .HasKey(r => r.Id);

            modelBuilder.Entity<Repository>()
                .HasOne(r => r.Owner)
                .WithMany(u => u.OwnedRepositories)
                .HasForeignKey(r => r.OwnerId)
                .OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<RepositoriesContributor>()
                .HasKey(rc => new { rc.UserId, rc.RepositoryId });

            modelBuilder.Entity<RepositoriesContributor>()
                .HasOne(rc => rc.User)
                .WithMany(u => u.ContributedRepositories)
                .HasForeignKey(rc => rc.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<RepositoriesContributor>()
                .HasOne(rc => rc.Repository)
                .WithMany(r => r.Contributors)
                .HasForeignKey(rc => rc.RepositoryId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Issue>()
                .HasKey(i => i.Id);

            modelBuilder.Entity<Issue>()
                .HasOne(i => i.Repository)
                .WithMany(r => r.Issues)
                .HasForeignKey(i => i.RepositoryId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Issue>()
                .HasOne(i => i.User)
                .WithMany(u => u.Issues)
                .HasForeignKey(i => i.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Commit>()
                .HasKey(c => c.Id);

            modelBuilder.Entity<Commit>()
                .HasOne(c => c.Repository)
                .WithMany(r => r.Commits)
                .HasForeignKey(c => c.RepositoryId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Commit>()
                .HasOne(c => c.Author)
                .WithMany(u => u.Commits)
                .HasForeignKey(c => c.AuthorId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<FileEntity>()
                .HasKey(f => f.Id);

            modelBuilder.Entity<FileEntity>()
                .HasOne(f => f.Commit)
                .WithMany(c => c.Files)
                .HasForeignKey(f => f.CommitId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
