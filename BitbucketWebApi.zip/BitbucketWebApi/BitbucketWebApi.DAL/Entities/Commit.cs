﻿using System;
using System.Collections.Generic;

namespace BitbucketWebApi.DAL.Entities
{
    public class Commit
    {
        public Guid Id { get; set; }
        public string Message { get; set; } = null!;
        public DateTime CommitDate { get; set; }
        public DateTime Date { get; set; }
        public Guid AuthorId { get; set; }
        public User Author { get; set; } = null!;
        public Guid RepositoryId { get; set; }
        public Repository Repository { get; set; } = null!;
        public User User { get; set; } = null!;

        public ICollection<File> Files { get; set; } = new List<File>();
    }
}
