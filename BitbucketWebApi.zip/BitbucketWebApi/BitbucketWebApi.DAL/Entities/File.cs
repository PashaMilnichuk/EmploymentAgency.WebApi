﻿using System;

namespace BitbucketWebApi.DAL.Entities
{
    public class File
    {
        public Guid Id { get; set; }
        public Guid CommitId { get; set; }
        public string FilePath { get; set; } = null!;
        public Commit Commit { get; set; } = null!;
        public string FileName { get; set; } = null!;
        public string Path { get; set; } = null!;
        public Guid RepositoryId { get; set; }

        public Repository Repository { get; set; } = null!;
    }
}
