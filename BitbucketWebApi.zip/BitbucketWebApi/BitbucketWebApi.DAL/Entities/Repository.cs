﻿using System;
using System.Collections.Generic;

namespace BitbucketWebApi.DAL.Entities
{
    public class Repository
    {
        public Guid Id { get; set; }
        public string Name { get; set; } = null!;
        public string Description { get; set; }
        public string Url { get; set; }
        public Guid? OwnerId { get; set; }
        public User? Owner { get; set; }
        public ICollection<File> Files { get; set; } = new List<File>();
        public ICollection<Issue> Issues { get; set; } = new List<Issue>();
        public ICollection<Commit> Commits { get; set; } = new List<Commit>();
        public ICollection<RepositoriesContributor> RepositoriesContributors { get; set; } = new List<RepositoriesContributor>();
        public ICollection<RepositoriesContributor> Contributors { get; set; } = new List<RepositoriesContributor>();

    }
}
