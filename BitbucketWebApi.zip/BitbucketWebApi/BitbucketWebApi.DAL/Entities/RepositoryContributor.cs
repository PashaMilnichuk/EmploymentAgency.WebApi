﻿using System;

namespace BitbucketWebApi.DAL.Entities
{
    public class RepositoriesContributor
    {
        public Guid RepositoryId { get; set; }
        public Repository Repository { get; set; } = null!;

        public Guid UserId { get; set; }
        public User User { get; set; } = null!;

        public string Role { get; set; } = "Contributor";
    }
}
