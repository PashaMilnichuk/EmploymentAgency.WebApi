﻿using System;
using System.Collections.Generic;

namespace BitbucketWebApi.DAL.Entities
{
    public class User
    {
        public Guid Id { get; set; }
        public string UserName { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string PasswordHash { get; set; } = null!;

        public ICollection<Repository> OwnedRepositories { get; set; } = new List<Repository>();
        public ICollection<RepositoriesContributor> ContributedRepositories { get; set; } = new List<RepositoriesContributor>();
        public ICollection<Issue> Issues { get; set; } = new List<Issue>();
        public ICollection<Commit> Commits { get; set; } = new List<Commit>();
    }
}
