using System;

namespace BitbucketWebApi.DAL.Entities
{
    public class Issue
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = null!;
        public string? Description { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ClosedAt { get; set; }
        public bool IsOpen { get; set; }

        public Guid RepositoryId { get; set; }
        public Guid UserId { get; set; }

        public Repository Repository { get; set; } = null!;
        public User User { get; set; } = null!;
    }
}
