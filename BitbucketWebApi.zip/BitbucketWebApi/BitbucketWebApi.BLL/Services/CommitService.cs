using BitbucketWebApi.BLL.DTOs.Commits;
using BitbucketWebApi.BLL.Interfaces;
using BitbucketWebApi.DAL;
using BitbucketWebApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace BitbucketWebApi.BLL.Services
{
    public class CommitService : ICommitService
    {
        private readonly BitbucketDbContext _context;

        public CommitService(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<CommitDto>> GetAllAsync()
        {
            return await _context.Commits
                .Select(c => new CommitDto
                {
                    Id = c.Id,
                    Message = c.Message,
                    RepositoryId = c.RepositoryId,
                })
                .ToListAsync();
        }

        public async Task<CommitDto?> GetByIdAsync(Guid id)
        {
            var entity = await _context.Commits.FindAsync(id);
            if (entity == null) return null;

            return new CommitDto
            {
                Id = entity.Id,
                Message = entity.Message,
                CommitDate = entity.CommitDate,
                RepositoryId = entity.RepositoryId,
                AuthorId = entity.AuthorId
            };
        }

        public async Task CreateAsync(CommitDto dto)
        {
            var entity = new Commit
            {
                Id = dto.Id == Guid.Empty ? Guid.NewGuid() : dto.Id,
                Message = dto.Message,
                CommitDate = dto.CommitDate,
                RepositoryId = dto.RepositoryId,
                AuthorId = dto.AuthorId
            };

            await _context.Commits.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateAsync(CommitDto dto)
        {
            var entity = await _context.Commits.FindAsync(dto.Id);
            if (entity == null) return false;

            entity.Message = dto.Message;
            entity.CommitDate = dto.CommitDate;
            entity.RepositoryId = dto.RepositoryId;
            entity.AuthorId = dto.AuthorId;

            _context.Commits.Update(entity);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task DeleteAsync(Guid id)
        {
            var entity = await _context.Commits.FindAsync(id);
            if (entity == null) return;

            _context.Commits.Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}
