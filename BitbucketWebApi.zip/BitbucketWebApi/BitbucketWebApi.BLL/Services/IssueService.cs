using BitbucketWebApi.BLL.DTOs.Issues;
using BitbucketWebApi.BLL.Interfaces;
using BitbucketWebApi.DAL;
using BitbucketWebApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BitbucketWebApi.BLL.Services
{
    public class IssueService : IIssueService
    {
        private readonly BitbucketDbContext _context;

        public IssueService(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<IssueDto>> GetAllAsync()
        {
            return await _context.Issues
                .Select(i => new IssueDto
                {
                    Id = i.Id,
                    Title = i.Title,
                    Description = i.Description,
                    RepositoryId = i.RepositoryId
                })
                .ToListAsync();
        }

        public async Task<IssueDto?> GetByIdAsync(Guid id)
        {
            var entity = await _context.Issues.FindAsync(id);
            if (entity == null) return null;

            return new IssueDto
            {
                Id = entity.Id,
                Title = entity.Title,
                Description = entity.Description,
                RepositoryId = entity.RepositoryId
            };
        }

        public async Task CreateAsync(IssueDto dto)
        {
            var entity = new Issue
            {
                Id = dto.Id == Guid.Empty ? Guid.NewGuid() : dto.Id,
                Title = dto.Title,
                Description = dto.Description,
                RepositoryId = dto.RepositoryId
            };

            await _context.Issues.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateAsync(IssueDto dto)
        {
            var entity = await _context.Issues.FindAsync(dto.Id);
            if (entity == null) return false;

            entity.Title = dto.Title;
            entity.Description = dto.Description;
            entity.RepositoryId = dto.RepositoryId;

            _context.Issues.Update(entity);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task DeleteAsync(Guid id)
        {
            var entity = await _context.Issues.FindAsync(id);
            if (entity == null) return;

            _context.Issues.Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}
