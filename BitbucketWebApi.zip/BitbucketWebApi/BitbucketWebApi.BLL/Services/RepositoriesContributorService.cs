﻿using BitbucketWebApi.BLL.DTOs.RepositoriesContributors;
using BitbucketWebApi.BLL.Interfaces;
using BitbucketWebApi.DAL;
using BitbucketWebApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BitbucketWebApi.BLL.Services
{
    public class RepositoriesContributorService : IRepositoriesContributorService
    {
        private readonly BitbucketDbContext _context;

        public RepositoriesContributorService(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<RepositoriesContributorDto>> GetAllAsync()
        {
            return await _context.RepositoriesContributors
                .Select(rc => new RepositoriesContributorDto
                {
                    RepositoryId = rc.RepositoryId,
                    UserId = rc.UserId
                })
                .ToListAsync();
        }

        public async Task<RepositoriesContributorDto?> GetByIdAsync(Guid userId, Guid repositoryId)
        {
            var entity = await _context.RepositoriesContributors
                .FirstOrDefaultAsync(rc => rc.UserId == userId && rc.RepositoryId == repositoryId);

            if (entity == null) return null;

            return new RepositoriesContributorDto
            {
                RepositoryId = entity.RepositoryId,
                UserId = entity.UserId
            };
        }

        public async Task CreateAsync(RepositoriesContributorDto dto)
        {
            var entity = new RepositoriesContributor
            {
                RepositoryId = dto.RepositoryId,
                UserId = dto.UserId
            };

            await _context.RepositoriesContributors.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateAsync(RepositoriesContributorDto dto)
        {
            var entity = await _context.RepositoriesContributors
                .FirstOrDefaultAsync(rc => rc.RepositoryId == dto.RepositoryId && rc.UserId == dto.UserId);

            if (entity == null) return false;

            _context.RepositoriesContributors.Update(entity);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task DeleteAsync(Guid userId, Guid repositoryId)
        {
            var entity = await _context.RepositoriesContributors
                .FirstOrDefaultAsync(rc => rc.UserId == userId && rc.RepositoryId == repositoryId);

            if (entity == null) return;

            _context.RepositoriesContributors.Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}
