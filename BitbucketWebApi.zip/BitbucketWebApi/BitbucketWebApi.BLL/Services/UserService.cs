using BitbucketWebApi.BLL.DTOs.Users;
using BitbucketWebApi.BLL.Interfaces;
using BitbucketWebApi.DAL;
using BitbucketWebApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BitbucketWebApi.BLL.Services
{
    public class UserService : IUserService
    {
        private readonly BitbucketDbContext _context;

        public UserService(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<UserDto>> GetAllUsersAsync()
        {
            return await _context.Users
                .Select(u => new UserDto { Id = u.Id, UserName = u.UserName, Email = u.Email })
                .ToListAsync();
        }

        public async Task<UserDto?> GetUserByIdAsync(Guid id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return null;
            return new UserDto { Id = user.Id, UserName = user.UserName, Email = user.Email };
        }

        public async Task<UserDto> CreateUserAsync(UserDto userDto)
        {
            var user = new User
            {
                UserName = userDto.UserName,
                Email = userDto.Email
            };
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            userDto.Id = user.Id;
            return userDto;
        }

        public async Task<bool> UpdateUserAsync(Guid id, UserDto userDto)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return false;
            user.UserName = userDto.UserName;
            user.Email = userDto.Email;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteUserAsync(Guid id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return false;
            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
