﻿using BitbucketWebApi.BLL.DTOs.Repositories;
using BitbucketWebApi.BLL.Interfaces;
using BitbucketWebApi.DAL;
using BitbucketWebApi.DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BitbucketWebApi.BLL.Services
{
    public class RepositoryService : IRepositoryService
    {
        private readonly BitbucketDbContext _context;

        public RepositoryService(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<RepositoryDto>> GetAllAsync()
        {
            return await _context.Repositories
            .Select(r => new RepositoryDto
             {
             Id = r.Id,
             Name = r.Name ?? string.Empty,
             Description = r.Description ?? string.Empty,
             Url = r.Url ?? string.Empty,
             OwnerId = r.OwnerId
             })
           .ToListAsync();

        }

        public async Task<RepositoryDto?> GetByIdAsync(Guid id)
        {
            var entity = await _context.Repositories.FindAsync(id);
            if (entity == null)
                return null;

            return new RepositoryDto
            {
                Id = entity.Id,
                Name = entity.Name,
                Description = entity.Description,
                OwnerId = entity.OwnerId,
                Url = entity.Url
            };
        }

        public async Task CreateAsync(RepositoryDto dto)
        {
            var entity = new Repository
            {
                Id = dto.Id == Guid.Empty ? Guid.NewGuid() : dto.Id,
                Name = dto.Name,
                Description = dto.Description,
                OwnerId = dto.OwnerId,
                Url = dto.Url
            };

            await _context.Repositories.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateAsync(RepositoryDto dto)
        {
            var entity = await _context.Repositories.FindAsync(dto.Id);
            if (entity == null)
                return false;

            entity.Name = dto.Name;
            entity.Description = dto.Description;
            entity.OwnerId = dto.OwnerId;
            entity.Url = dto.Url;

            _context.Repositories.Update(entity);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task DeleteAsync(Guid id)
        {
            var entity = await _context.Repositories.FindAsync(id);
            if (entity == null)
                return;

            _context.Repositories.Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}
