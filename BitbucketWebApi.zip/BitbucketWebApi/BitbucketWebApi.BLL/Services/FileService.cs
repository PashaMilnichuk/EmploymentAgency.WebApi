using BitbucketWebApi.BLL.DTOs.Files;
using BitbucketWebApi.BLL.Interfaces;
using FileEntity = BitbucketWebApi.DAL.Entities.File;
using BitbucketWebApi.DAL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FileDto = BitbucketWebApi.BLL.DTOs.Files.FileDto;

namespace BitbucketWebApi.BLL.Services
{
    public class FileService : IFileService
    {
        private readonly BitbucketDbContext _context;

        public FileService(BitbucketDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<FileDto>> GetAllAsync()
        {
            return await _context.Files
                .Select(f => new FileDto
                {
                    Id = f.Id,
                    FileName = f.FileName,
                    FilePath = f.FilePath,
                    RepositoryId = f.RepositoryId
                })
                .ToListAsync();
        }

        public async Task<FileDto?> GetByIdAsync(Guid id)
        {
            var entity = await _context.Files.FindAsync(id);
            if (entity == null) return null;

            return new FileDto
            {
                Id = entity.Id,
                FileName = entity.FileName,
                FilePath = entity.FilePath,
                RepositoryId = entity.RepositoryId
            };
        }

        public async Task CreateAsync(FileDto dto)
        {
            var entity = new FileEntity
            {
                Id = dto.Id == Guid.Empty ? Guid.NewGuid() : dto.Id,
                FileName = dto.FileName,
                FilePath = dto.FilePath,
                RepositoryId = dto.RepositoryId
            };

            await _context.Files.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateAsync(FileDto dto)
        {
            var entity = await _context.Files.FindAsync(dto.Id);
            if (entity == null) return false;

            entity.FileName = dto.FileName;
            entity.FilePath = dto.FilePath;
            entity.RepositoryId = dto.RepositoryId;

            _context.Files.Update(entity);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task DeleteAsync(Guid id)
        {
            var entity = await _context.Files.FindAsync(id);
            if (entity == null) return;

            _context.Files.Remove(entity);
            await _context.SaveChangesAsync();
        }
    }
}
