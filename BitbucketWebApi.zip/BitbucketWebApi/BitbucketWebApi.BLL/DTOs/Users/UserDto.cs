﻿using System;

namespace BitbucketWebApi.BLL.DTOs.Users
{
    public class UserDto
    {
        public Guid Id { get; set; }
        public string UserName { get; set; } = null!;
        public string Email { get; set; } = null!;
    }
}
