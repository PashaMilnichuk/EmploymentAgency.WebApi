using System;

namespace BitbucketWebApi.BLL.DTOs.Issues
{
    public class IssueDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; } = null!;
        public string Description { get; set; } = null!;
        public Guid RepositoryId { get; set; }
        public Guid UserId { get; set; }
    }
}
