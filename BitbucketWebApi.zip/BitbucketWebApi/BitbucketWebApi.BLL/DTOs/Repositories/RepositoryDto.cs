using System;

namespace BitbucketWebApi.BLL.DTOs.Repositories
{
    public class RepositoryDto
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public Guid? OwnerId { get; set; }
        public string? Url { get; set; }
    }
}
