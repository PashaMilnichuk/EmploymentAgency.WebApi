﻿using System;

namespace BitbucketWebApi.BLL.DTOs.Commits
{
    public class CommitDto
    {
        public Guid Id { get; set; }
        public string Message { get; set; } = null!;
        public DateTime CommitDate { get; set; }
        public DateTime Date { get; set; }
        public Guid RepositoryId { get; set; }
        public Guid AuthorId { get; set; }
    }
}
