using System;

namespace BitbucketWebApi.BLL.DTOs.RepositoriesContributors
{
    public class RepositoriesContributorDto
    {
        public Guid UserId { get; set; }
        public Guid RepositoryId { get; set; }
    }
}
