using BitbucketWebApi.BLL.DTOs.Files;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace BitbucketWebApi.BLL.Interfaces
{
    public interface IFileService
    {
        Task<IEnumerable<FileDto>> GetAllAsync();
        Task<FileDto?> GetByIdAsync(Guid id);
        Task CreateAsync(FileDto dto);
        Task<bool> UpdateAsync(FileDto dto);
        Task DeleteAsync(Guid id);
    }
}
