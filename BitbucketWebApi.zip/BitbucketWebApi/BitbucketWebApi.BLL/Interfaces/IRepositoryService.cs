using BitbucketWebApi.BLL.DTOs.Users;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BitbucketWebApi.BLL.DTOs.Repositories;

namespace BitbucketWebApi.BLL.Interfaces
{
    public interface IRepositoryService
    {
        Task<IEnumerable<RepositoryDto>> GetAllAsync();
        Task<RepositoryDto?> GetByIdAsync(Guid id);
        Task CreateAsync(RepositoryDto dto);
        Task<bool> UpdateAsync(RepositoryDto dto);
        Task DeleteAsync(Guid id);
    }
}
