using BitbucketWebApi.BLL.DTOs.RepositoriesContributors;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public interface IRepositoriesContributorService
{
    Task<IEnumerable<RepositoriesContributorDto>> GetAllAsync();
    Task<RepositoriesContributorDto?> GetByIdAsync(Guid userId, Guid repositoryId);
    Task CreateAsync(RepositoriesContributorDto dto);
    Task<bool> UpdateAsync(RepositoriesContributorDto dto);
    Task DeleteAsync(Guid userId, Guid repositoryId);
}
