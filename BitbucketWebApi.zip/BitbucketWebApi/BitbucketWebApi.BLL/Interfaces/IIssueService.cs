using BitbucketWebApi.BLL.DTOs.Issues;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BitbucketWebApi.BLL.Interfaces
{
    public interface IIssueService
    {
        Task<IEnumerable<IssueDto>> GetAllAsync();
        Task<IssueDto?> GetByIdAsync(Guid id);
        Task CreateAsync(IssueDto dto);
        Task<bool> UpdateAsync(IssueDto dto);
        Task DeleteAsync(Guid id);
    }
}
