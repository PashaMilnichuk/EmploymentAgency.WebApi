using BitbucketWebApi.BLL.DTOs.Commits;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BitbucketWebApi.BLL.Interfaces
{
    public interface ICommitService
    {
        Task<IEnumerable<CommitDto>> GetAllAsync();
        Task<CommitDto?> GetByIdAsync(Guid id);
        Task CreateAsync(CommitDto dto);
        Task<bool> UpdateAsync(CommitDto dto);
        Task DeleteAsync(Guid id);
    }
}
