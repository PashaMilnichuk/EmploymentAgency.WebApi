using FluentValidation;
using BitbucketWebApi.BLL.DTOs.RepositoriesContributors;

namespace BitbucketWebApi.BLL.Validators
{
    public class RepositoriesContributorDtoValidator : AbstractValidator<RepositoriesContributorDto>
    {
        public RepositoriesContributorDtoValidator()
        {
            RuleFor(x => x.RepositoryId).NotEmpty();
            RuleFor(x => x.UserId).NotEmpty();
        }
    }
}
