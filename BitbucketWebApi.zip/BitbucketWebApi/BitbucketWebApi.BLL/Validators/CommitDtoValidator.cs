using BitbucketWebApi.BLL.DTOs.Commits;
using FluentValidation;
using System;


namespace BitbucketWebApi.BLL.Validators
{
    public class CommitDtoValidator : AbstractValidator<CommitDto>
    {
        public CommitDtoValidator()
        {
            RuleFor(x => x.Message)
                .NotEmpty().WithMessage("Message is required.")
                .MaximumLength(500);
            RuleFor(x => x.Date)
                .LessThanOrEqualTo(DateTime.Now).WithMessage("Date cannot be in the future.");
            RuleFor(x => x.RepositoryId)
                .NotEmpty();
            RuleFor(x => x.AuthorId)
                .NotEmpty();
        }
    }
}
