﻿using FluentValidation;
using BitbucketWebApi.BLL.DTOs.Issues;

namespace BitbucketWebApi.BLL.Validators
{
    public class IssueDtoValidator : AbstractValidator<IssueDto>
    {
        public IssueDtoValidator()
        {
            RuleFor(x => x.Title)
                .NotEmpty().WithMessage("Title is required.")
                .MaximumLength(200);

            RuleFor(x => x.Description)
                .MaximumLength(1000);

        }
    }
}
