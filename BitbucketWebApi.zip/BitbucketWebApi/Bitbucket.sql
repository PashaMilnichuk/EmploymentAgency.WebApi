-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: bitbucket
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `commits`
--

DROP TABLE IF EXISTS `commits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commits` (
  `Id` char(36) NOT NULL,
  `Message` varchar(1000) NOT NULL,
  `IssueId` char(36) DEFAULT NULL,
  `RepositoryId` char(36) NOT NULL,
  `ContributorId` char(36) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `commits_ibfk_4` (`IssueId`),
  KEY `commits_ibfk_2` (`RepositoryId`),
  KEY `commits_ibfk_3` (`ContributorId`),
  CONSTRAINT `commits_ibfk_2` FOREIGN KEY (`RepositoryId`) REFERENCES `repositories` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `commits_ibfk_3` FOREIGN KEY (`ContributorId`) REFERENCES `users` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `commits_ibfk_4` FOREIGN KEY (`IssueId`) REFERENCES `issues` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commits`
--

LOCK TABLES `commits` WRITE;
/*!40000 ALTER TABLE `commits` DISABLE KEYS */;
INSERT INTO `commits` VALUES ('1','Deleted deprecated functionality from index.cpp','58','17','8'),('10','Deleted deprecated functionality from index.net',NULL,'27','1'),('11','Patch Model.MDv.','52','7','16'),('12','Deleted deprecated functionality from Music.jpg','41','6','11'),('13','Implemented index.net functionality',NULL,'15','11'),('14','Fixed index.dd','40','1','7'),('15','Fixed index.soshy',NULL,'19','1'),('16','Patch Operate.xixv.',NULL,'21','4'),('17','Hotfix for bug in Database.dd','73','14','11'),('18','Hotfix for bug in init.xml','3','10','11'),('19','Hotfix for bug in compile.png','2','7','3'),('2','Created README.MD','15','14','8'),('20','Fixed init.xml','15','30','15'),('21','Hotfix for bug in Administrate.soshy','8','26','19'),('22','Implemented Index.class functionality',NULL,'14','13'),('23','Fixed security issue in Beat.bat',NULL,'7','4'),('24','Patch index.netv.','36','16','14'),('25','Implemented compile.png functionality','21','10','2'),('26','Fixed security issue in compile.html','72','22','4'),('27','Patch index.ddv.','62','6','3'),('28','Fixed Controller.php','4','9','7'),('29','Patch Find.javav.','29','28','4'),('3','Initial Commit','52','24','1'),('30','Hotfix for bug in compile.ivory','43','25','14'),('31','Fixed security issue in compile.png','64','16','10'),('32','Implemented Beat.bat functionality',NULL,'5','18'),('33','Patch Database.ddv.','17','4','15'),('34','Deleted deprecated functionality from Model.MD','48','17','7'),('35','Patch init.txtv.','51','11','2'),('36','Fixed menu.net','48','3','18'),('37','Implemented Find.java functionality',NULL,'1','1'),('38','Deleted deprecated functionality from index.intro','70','18','16'),('39','Implemented Beat.html functionality','51','1','5'),('4','Implemented config.json functionality','15','10','12'),('40','Deleted deprecated functionality from Database.dd',NULL,'2','13'),('41','Implemented Trade.idk functionality',NULL,'15','19'),('42','Hotfix for bug in compile.html','15','6','19'),('43','Fixed security issue in Search.py','17','21','15'),('44','Fixed security issue in Accelerate.sick','20','2','17'),('45','Fixed security issue in Administrate.soshy','58','25','1'),('46','Fixed security issue in file.txt',NULL,'1','14'),('47','Fixed Operate.xix','29','27','15'),('48','Implemented init.xml functionality','39','7','17'),('49','Fixed config.json','1','28','5'),('5','Deleted deprecated functionality from index.dd','32','13','18'),('50','Implemented Database.dd functionality',NULL,'29','8'),('6','Hotfix for bug in Index.class','71','19','1'),('7','Patch Index.javav.','38','8','11'),('8','Deleted deprecated functionality from Operate.xix',NULL,'28','9'),('9','Fixed security issue in file.png',NULL,'6','2');
/*!40000 ALTER TABLE `commits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Size` float NOT NULL,
  `ParentId` int DEFAULT NULL,
  `CommitId` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ParentId` (`ParentId`),
  KEY `CommitId` (`CommitId`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'Trade.idk',2598,1,1),(2,'menu.net',9238.31,2,2),(3,'Administrate.soshy',1246.93,3,3),(4,'Controller.php',7353.15,4,4),(5,'Find.java',9957.86,5,5),(6,'Controller.json',14034.9,3,6),(7,'Operate.xix',7662.92,7,7),(8,'file.sick',10548.3,8,8),(9,'config.dd',8745.77,9,9),(10,'Index.java',6121.35,10,10),(11,'compile.ivory',1185.04,11,1),(12,'Model.MD',4753.67,3,12),(13,'Beat.html',907.3,13,13),(14,'READ.img',2627.6,14,7),(15,'Search.py',8831.43,15,15),(16,'Controller.intro',27302.8,11,1),(17,'Login.html',2863.23,16,17),(18,'Administrate.go',24612.6,9,18),(19,'READ.html',2396.47,8,1),(20,'index.net',9261.71,20,20),(21,'Index.class',4001.15,21,21),(22,'config.json',6049.09,22,22),(23,'pipeline.dd',18407.7,NULL,19),(24,'Accelerate.dd',23042.9,24,19),(25,'Database.dd',14905.6,NULL,25),(26,'Login.db',8015.83,NULL,21),(27,'Beat.bat',21432,25,12),(28,'Jason.txt',10317.5,NULL,28),(29,'Jason.exe',28209.2,8,25),(30,'Accelerate.idk',5520.3,30,1),(31,'file.txt',5514.02,27,1),(32,'Music.jpg',917.75,1,3),(33,'Root.net',6784.97,8,28),(34,'sound.sick',8749.82,20,16),(35,'index.dd',35942.2,NULL,35),(36,'index.intro',14325.3,26,36),(37,'init.xml',40028,NULL,22),(38,'file.cpp',3038.23,NULL,22),(39,'Beat.xix',5877.21,22,31),(40,'index.cpp',28912.2,2,40),(41,'compile.png',20510.1,22,24),(42,'Register.py',2037.26,5,27),(43,'init.txt',16089.8,28,4),(44,'View.dd',2470.36,NULL,44),(45,'file.png',7755.49,NULL,23),(46,'index.db',3821.36,11,46),(47,'Accelerate.sick',5774.32,47,47),(48,'index.soshy',30523,30,26),(49,'compile.html',27402.6,28,24),(50,'Bean.php',4184.45,20,35);
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `Id` char(36) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `IssueStatus` varchar(20) NOT NULL,
  `RepositoryId` int NOT NULL,
  `AssigneeId` char(36) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `RepositoryId` (`RepositoryId`),
  KEY `AssigneeId` (`AssigneeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES ('1','Invalid welcoming message in Controller.json','closed',25,'5'),('10','Unreachable code in Index.class stops compilation flow','clear',24,'4'),('11','Loose Cohesion and Strong Coupling in Beat.bat','clear',34,'7'),('12','Compilation failed while trying to execute READ.img','closed',16,'1'),('13','Critical bug in pipeline.dd ruins application when executed','clear',3,'16'),('14','Implement documentation for Register.py module','clear',1,'17'),('15','Compilation failed while trying to execute Search.py','clear',19,'1'),('16','Inappropriate prompt from READ.html','fixed',8,'1'),('17','Unreachable code in index.intro stops compilation flow','opened',22,'9'),('18','Critical bug in Jason.exe ruins application when executed','opened',29,'14'),('19','Compilation failed while trying to execute Beat.bat','closed',10,'18'),('2','Invalid welcoming message in READ.html','opened',34,'13'),('20','init.txt breaks down after startup','fixed',4,'10'),('21','compile.png breaks down after startup','clear',7,'9'),('22','Unreachable code in index.net stops compilation flow','fixed',16,'9'),('23','Inappropriate prompt from index.net','closed',18,'1'),('24','Implement documentation for index.intro module','closed',9,'11'),('25','Invalid welcoming message in file.sick','clear',20,'5'),('26','Unreachable code in Login.html stops compilation flow','fixed',27,'1'),('27','Hotfix for security issue in View.dd introduces new security issue','clear',30,'6'),('28','Hotfix for security issue in Jason.exe introduces new security issue','closed',15,'2'),('29','Loose Cohesion and Strong Coupling in READ.img','fixed',13,'8'),('3','Unreachable code in Find.java stops compilation flow','closed',11,'11'),('30','Inappropriate prompt from config.dd','fixed',29,'12'),('31','Invalid welcoming message in Administrate.soshy','closed',12,'10'),('32','Hotfix for security issue in Index.class introduces new security issue','clear',5,'16'),('33','Loose Cohesion and Strong Coupling in Bean.php','clear',19,'8'),('34','Loose Cohesion and Strong Coupling in file.png','closed',14,'16'),('35','Invalid welcoming message in Accelerate.sick','clear',17,'14'),('36','Compilation failed while trying to execute index.intro','clear',11,'19'),('37','Security Flaw in Music.jpg inner code','closed',11,'11'),('38','index.db breaks down after startup','closed',23,'8'),('39','Unreachable code in Music.jpg stops compilation flow','clear',5,'19'),('4','Implement documentation for Jason.exe module','closed',16,'5'),('40','Unimplemented exception thrown in Accelerate.sick','clear',20,'1'),('41','Invalid welcoming message in Search.py','clear',32,'14'),('42','Invalid welcoming message in index.cpp','clear',26,'15'),('43','Compilation failed while trying to execute index.db','clear',15,'1'),('44','Root.net breaks down after startup','fixed',31,'5'),('45','Unimplemented exception thrown in init.txt','clear',30,'2'),('46','Critical bug in compile.html ruins application when executed','opened',3,'11'),('47','Inappropriate prompt from index.db','clear',30,'14'),('48','Implement documentation for file.cpp module','opened',12,'14'),('49','Inappropriate prompt from Register.py','fixed',9,'2'),('5','Unreachable code in Model.MD stops compilation flow','closed',6,'17'),('50','Implement documentation for index.db module','fixed',17,'7'),('51','Critical bug in Trade.idk ruins application when executed','clear',27,'13'),('52','Unimplemented exception thrown in Beat.xix','fixed',16,'6'),('53','Unimplemented exception thrown in Administrate.go','clear',1,'17'),('54','Unimplemented exception thrown in Login.html','clear',32,'1'),('55','Unreachable code in Register.py stops compilation flow','opened',21,'18'),('56','Hotfix for security issue in pipeline.dd introduces new security issue','fixed',27,'17'),('57','Invalid welcoming message in init.txt','fixed',14,'15'),('58','Implement documentation for Administrate.soshy module','opened',28,'1'),('59','Hotfix for security issue in index.soshy introduces new security issue','closed',11,'3'),('6','Security Flaw in Accelerate.dd inner code','opened',5,'14'),('60','Implement documentation for file.sick module','closed',31,'10'),('61','Loose Cohesion and Strong Coupling in Root.net','closed',13,'7'),('62','Compilation failed while trying to execute index.net','opened',8,'19'),('63','Unimplemented exception thrown in Register.py','clear',21,'19'),('64','file.sick breaks down after startup','closed',35,'19'),('65','Security Flaw in pipeline.dd inner code','opened',3,'19'),('66','Invalid welcoming message in index.intro','closed',8,'6'),('67','Security Flaw in Beat.xix inner code','opened',33,'7'),('68','Inappropriate prompt from compile.ivory','clear',11,'4'),('69','Inappropriate prompt from Search.py','clear',12,'17'),('7','Compilation failed while trying to execute Bean.php','closed',14,'14'),('70','Hotfix for security issue in Login.db introduces new security issue','clear',2,'19'),('71','Implement documentation for Index.class module','closed',32,'3'),('72','Loose Cohesion and Strong Coupling in index.soshy','opened',29,'12'),('73','Loose Cohesion and Strong Coupling in Beat.html','opened',2,'15'),('74','Compilation failed while trying to execute init.xml','opened',24,'12'),('75','Critical bug in Controller.php ruins application when executed','fixed',8,'16'),('8','Critical bug in sound.sick ruins application when executed','opened',24,'11'),('9','Invalid welcoming message in Find.java','clear',25,'12');
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repositories`
--

DROP TABLE IF EXISTS `repositories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repositories` (
  `Id` char(36) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `OwnerId` char(36) DEFAULT NULL,
  `Url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repositories`
--

LOCK TABLES `repositories` WRITE;
/*!40000 ALTER TABLE `repositories` DISABLE KEYS */;
INSERT INTO `repositories` VALUES ('5aab03ac-54e1-11f0-9d55-025071d4436c','RepoName','Description',NULL,'http://example.com'),('9a3d1f13-54e1-11f0-9d55-025071d4436c','WorkWork',NULL,NULL,NULL),('9a3d23d4-54e1-11f0-9d55-025071d4436c','SortedTupleJS',NULL,NULL,NULL),('9a3d259e-54e1-11f0-9d55-025071d4436c','KartinaJS',NULL,NULL,NULL),('9a3d2740-54e1-11f0-9d55-025071d4436c','SpiralSort',NULL,NULL,NULL),('9a3d28fe-54e1-11f0-9d55-025071d4436c','Vendigo-RPG',NULL,NULL,NULL),('9a3d2ad9-54e1-11f0-9d55-025071d4436c','Kartica',NULL,NULL,NULL),('9a3d2c4b-54e1-11f0-9d55-025071d4436c','SignalR',NULL,NULL,NULL),('9a3d2db2-54e1-11f0-9d55-025071d4436c','ASP.NET',NULL,NULL,NULL),('9a3d2f1e-54e1-11f0-9d55-025071d4436c','MySQL',NULL,NULL,NULL),('9a3d30b6-54e1-11f0-9d55-025071d4436c','InnoDB',NULL,NULL,NULL),('9a3d321b-54e1-11f0-9d55-025071d4436c','Catalina',NULL,NULL,NULL),('9a3d3383-54e1-11f0-9d55-025071d4436c','Tumbalore',NULL,NULL,NULL),('9a3d34e1-54e1-11f0-9d55-025071d4436c','JosephineDB',NULL,NULL,NULL),('9a3d3647-54e1-11f0-9d55-025071d4436c','Intrigued-RPG',NULL,NULL,NULL),('9a3d37af-54e1-11f0-9d55-025071d4436c','Maxima',NULL,NULL,NULL),('9a3d3914-54e1-11f0-9d55-025071d4436c','Calculus',NULL,NULL,NULL),('9a3d3a73-54e1-11f0-9d55-025071d4436c','Assembly-Force',NULL,NULL,NULL),('9a3d3be6-54e1-11f0-9d55-025071d4436c','Mesmerize-Frameowork',NULL,NULL,NULL),('9a3d3d4d-54e1-11f0-9d55-025071d4436c','maxOut',NULL,NULL,NULL),('9a3d3eab-54e1-11f0-9d55-025071d4436c','inspiration',NULL,NULL,NULL),('9a3d4006-54e1-11f0-9d55-025071d4436c','Bau',NULL,NULL,NULL),('9a3d4174-54e1-11f0-9d55-025071d4436c','Practiq',NULL,NULL,NULL),('9a3d4346-54e1-11f0-9d55-025071d4436c','Softuni-Teamwork',NULL,NULL,NULL),('9a3d44c3-54e1-11f0-9d55-025071d4436c','Daun',NULL,NULL,NULL),('9a3d4699-54e1-11f0-9d55-025071d4436c','Kimmers',NULL,NULL,NULL),('9a3d480c-54e1-11f0-9d55-025071d4436c','Defalte_pf',NULL,NULL,NULL),('9a3d496e-54e1-11f0-9d55-025071d4436c','Kras_par_ti',NULL,NULL,NULL),('9a3d4ad1-54e1-11f0-9d55-025071d4436c','Antiq',NULL,NULL,NULL),('9a3d4c4d-54e1-11f0-9d55-025071d4436c','Dantelle',NULL,NULL,NULL),('9a3d4db3-54e1-11f0-9d55-025071d4436c','DELET THIS',NULL,NULL,NULL),('9a3d4f1e-54e1-11f0-9d55-025071d4436c','IncreaseRepo',NULL,NULL,NULL),('9a3d508d-54e1-11f0-9d55-025071d4436c','ContinuousIntegration',NULL,NULL,NULL),('9a3d5206-54e1-11f0-9d55-025071d4436c','IndigoDB',NULL,NULL,NULL),('9a3d536a-54e1-11f0-9d55-025071d4436c','DundaApp',NULL,NULL,NULL),('9a3d54ca-54e1-11f0-9d55-025071d4436c','Citros',NULL,NULL,NULL),('9a3d5627-54e1-11f0-9d55-025071d4436c','BogoApp',NULL,NULL,NULL);
/*!40000 ALTER TABLE `repositories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repositoriescontributors`
--

DROP TABLE IF EXISTS `repositoriescontributors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repositoriescontributors` (
  `RepositoryId` char(36) NOT NULL,
  `ContributorId` char(36) NOT NULL,
  PRIMARY KEY (`RepositoryId`,`ContributorId`),
  KEY `repositoriescontributors_ibfk_2` (`ContributorId`),
  CONSTRAINT `repositoriescontributors_ibfk_1` FOREIGN KEY (`RepositoryId`) REFERENCES `repositories` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `repositoriescontributors_ibfk_2` FOREIGN KEY (`ContributorId`) REFERENCES `users` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repositoriescontributors`
--

LOCK TABLES `repositoriescontributors` WRITE;
/*!40000 ALTER TABLE `repositoriescontributors` DISABLE KEYS */;
INSERT INTO `repositoriescontributors` VALUES ('1','1'),('11','1'),('13','1'),('2','1'),('24','1'),('26','1'),('27','1'),('3','1'),('30','1'),('31','1'),('33','1'),('6','1'),('7','1'),('1','10'),('22','10'),('27','10'),('16','11'),('26','11'),('30','11'),('25','12'),('30','12'),('33','12'),('5','12'),('21','13'),('28','13'),('31','13'),('9','13'),('1','14'),('3','14'),('32','14'),('33','14'),('34','14'),('4','14'),('10','15'),('13','15'),('19','15'),('2','15'),('24','15'),('25','15'),('29','15'),('6','15'),('18','16'),('2','16'),('26','16'),('28','16'),('31','16'),('32','16'),('8','16'),('15','17'),('28','17'),('3','17'),('30','17'),('34','17'),('1','18'),('16','18'),('23','18'),('10','19'),('23','19'),('30','19'),('32','19'),('7','19'),('10','2'),('12','2'),('16','2'),('27','2'),('30','2'),('5','2'),('10','3'),('2','3'),('21','3'),('22','3'),('29','3'),('3','3'),('14','4'),('16','4'),('17','4'),('22','4'),('18','5'),('22','5'),('29','5'),('8','5'),('9','5'),('1','6'),('20','6'),('25','6'),('29','6'),('7','6'),('11','7'),('13','7'),('14','7'),('3','7'),('7','7'),('14','8'),('22','8'),('32','8'),('13','9'),('15','9'),('22','9'),('5','9'),('9','9');
/*!40000 ALTER TABLE `repositoriescontributors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `Id` char(36) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('18ef16ff-54e0-11f0-9d55-025071d4436c','UnderSinduxrein','4l8nYGTKMW','azfex@gmail.com'),('18ef1dc6-54e0-11f0-9d55-025071d4436c','ScoreSinduxIana','8xI:@-j2_.T','rog@asus.co'),('18ef20bc-54e0-11f0-9d55-025071d4436c','RoundAntigaBel','4S>7EUNeUC@kv','diplomat@po.bo'),('18ef23b4-54e0-11f0-9d55-025071d4436c','DarkImmagidsa','R.fh[f1Zh>2','sys@admin.bg'),('18ef26df-54e0-11f0-9d55-025071d4436c','RoundInspecindi','AdKs>q]u7P`C','katr@kiper.eu'),('18ef2a2c-54e0-11f0-9d55-025071d4436c','AryaNinehow','X6j>`Huf2F(I','wrec@soft.wrap'),('18ef2c76-54e0-11f0-9d55-025071d4436c','ScoreAntigarein','UUD3H))<','dec@int.float'),('18ef2eef-54e0-11f0-9d55-025071d4436c','TheDivineBel','-gCi:_Ub?ypT','rindiy@abv.bg'),('18ef3154-54e0-11f0-9d55-025071d4436c','RoundArmydsa','SZ?F-:hW','com@gmail.user'),('18ef33e4-54e0-11f0-9d55-025071d4436c','HighAsmahow','lyqF\\vUG','svik@kiwi.mandarin'),('18ef365d-54e0-11f0-9d55-025071d4436c','ZendArmyhow','DbW>9,','rip@pob.cid'),('18ef38bf-54e0-11f0-9d55-025071d4436c','BlaAntigadsa',':Q5wjT4[e','kuf@abv.bg'),('18ef3b30-54e0-11f0-9d55-025071d4436c','BlaImmagiIana','upE;fg6+)n','stun@asd.cdd'),('18ef3ddc-54e0-11f0-9d55-025071d4436c','ANinedsa','El[MwhxY)J','indie@yahoo.com'),('18ef405e-54e0-11f0-9d55-025071d4436c','ScoreImmagidefon','`NGU>oS','daffy@yandex.bg'),('18ef42a8-54e0-11f0-9d55-025071d4436c','BlaSinduxrein','wJyfcwg*','toni@donald.eu'),('18ef44f5-54e0-11f0-9d55-025071d4436c','WhoDenoteBel','ajmISQi*','tinny@pd.cd'),('18ef4786-54e0-11f0-9d55-025071d4436c','WhatTerrorBel','R+-<+..Pl3j^','joseph@lon.co.uk'),('18ef49f0-54e0-11f0-9d55-025071d4436c','AryaDenotehow','NNY5<e=','corect@asd.asd'),('18ef4c41-54e0-11f0-9d55-025071d4436c','UnveiledDenoteIana','no0*[ijt','default@ooo.com');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'bitbucket'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-01 21:04:15
