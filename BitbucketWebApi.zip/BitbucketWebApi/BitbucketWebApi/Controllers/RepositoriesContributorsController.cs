﻿using BitbucketWebApi.BLL.DTOs.RepositoriesContributors;
using BitbucketWebApi.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace BitbucketWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RepositoriesContributorsController : ControllerBase
    {
        private readonly IRepositoriesContributorService _service;

        public RepositoriesContributorsController(IRepositoriesContributorService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var items = await _service.GetAllAsync();
            return Ok(items);
        }

        [HttpGet("{userId}/{repositoryId}")]
        public async Task<IActionResult> GetById(Guid userId, Guid repositoryId)
        {
            var item = await _service.GetByIdAsync(userId, repositoryId);
            if (item == null) return NotFound();
            return Ok(item);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] RepositoriesContributorDto dto)
        {
            await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { userId = dto.UserId, repositoryId = dto.RepositoryId }, dto);
        }

        [HttpPut("{userId}/{repositoryId}")]
        public async Task<IActionResult> Update(Guid userId, Guid repositoryId, [FromBody] RepositoriesContributorDto dto)
        {
            if (userId != dto.UserId || repositoryId != dto.RepositoryId)
                return BadRequest("UserId and RepositoryId in URL must match those in the body.");

            var updated = await _service.UpdateAsync(dto);
            if (!updated) return NotFound();

            return NoContent();
        }

        [HttpDelete("{userId}/{repositoryId}")]
        public async Task<IActionResult> Delete(Guid userId, Guid repositoryId)
        {
            await _service.DeleteAsync(userId, repositoryId);
            return NoContent();
        }
    }
}
