using BitbucketWebApi.BLL.DTOs.Files;
using BitbucketWebApi.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BitbucketWebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FilesController : ControllerBase
    {
        private readonly IFileService _fileService;

        public FilesController(IFileService fileService)
        {
            _fileService = fileService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<FileDto>>> GetAll()
        {
            var files = await _fileService.GetAllAsync();
            return Ok(files);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<FileDto>> GetById(Guid id)
        {
            var file = await _fileService.GetByIdAsync(id);
            if (file == null) return NotFound();
            return Ok(file);
        }

        [HttpPost]
        public async Task<IActionResult> Create(FileDto dto)
        {
            await _fileService.CreateAsync(dto);
            return Ok();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, FileDto dto)
        {
            if (id != dto.Id) return BadRequest();
            var updated = await _fileService.UpdateAsync(dto);
            if (!updated) return NotFound();
            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            await _fileService.DeleteAsync(id);
            return Ok();
        }
    }
}
