using BitbucketWebApi.BLL.DTOs.Commits;
using BitbucketWebApi.BLL.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class CommitsController : ControllerBase
{
    private readonly ICommitService _commitService;

    public CommitsController(ICommitService commitService)
    {
        _commitService = commitService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var commits = await _commitService.GetAllAsync();
        return Ok(commits);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(Guid id)
    {
        var commit = await _commitService.GetByIdAsync(id);
        if (commit == null) return NotFound();
        return Ok(commit);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CommitDto dto)
    {
        await _commitService.CreateAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = dto.Id }, dto);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(Guid id, CommitDto dto)
    {
        if (id != dto.Id) return BadRequest();

        var updated = await _commitService.UpdateAsync(dto);
        if (!updated) return NotFound();

        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        await _commitService.DeleteAsync(id);
        return NoContent();
    }
}
